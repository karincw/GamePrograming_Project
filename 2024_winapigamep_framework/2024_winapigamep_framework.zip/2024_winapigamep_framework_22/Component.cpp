#include "pch.h"
#include "Component.h"

Component::Component()
	: m_pOwner(nullptr)
{

}

Component::~Component()
{

}
