#pragma once
#include "Scene.h"
class StageScene :
    public Scene
{
public:
	void Init() override;
};

